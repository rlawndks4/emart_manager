const local = require('./localStrategy');

module.exports = (passport) =>{
    local(passport);
}